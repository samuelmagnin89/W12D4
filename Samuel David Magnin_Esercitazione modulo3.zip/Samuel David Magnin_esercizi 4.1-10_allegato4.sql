/* Task 4: Dopo aver popolate le tabelle, scrivi delle query utili a:
1)	Verificare che i campi definiti come PK siano univoci. 
In altre parole, scrivi una query per determinare l�univocit� dei valori di ciascuna PK (una query per tabella implementata).*/

-- I RECORD SELEZIONATI DI SEGUITO DEVONO ESSERE VUOTI

SELECT COUNT(*), ProductID
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1

SELECT COUNT(*), StateID
FROM Region
GROUP BY StateID
HAVING COUNT(*) > 1

SELECT COUNT(*), SalesID
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1

/* 2)	Esporre l�elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
il nome dello stato, il nome della regione di vendita 
e un campo booleano valorizzato in base alla condizione che siano passati pi� di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)*/

SELECT 
	s.SalesID, 
	s.SalesDate, 
	p.ProductName, 
	p.CategoryName,  
	r.StateName, 
	r.RegionName,
	CASE
		WHEN DATEDIFF (day, s.SalesDate, GETDATE()) > 180 THEN 'True'
		WHEN DATEDIFF (day, s.SalesDate, GETDATE()) <= 180 THEN 'False'
		END AS '180+Sales' 
FROM Sales as s
INNER JOIN Product as p
ON s.ProductID = p.ProductID
INNER JOIN Region as r
ON s.StateID = r.StateID
GROUP BY 
	s.SalesID, 
	s.SalesDate, 
	p.ProductName, 
	p.CategoryName,  
	r.StateName, 
	r.RegionName
ORDER BY s.SalesID;


-- 3)	Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

SELECT
	p.ProductID, 
	p.ProductName, 
	YEAR (s.SalesDate) as Year,
	SUM (s.SalesAmount) as TotalSalesPerYear
FROM Sales as s
LEFT JOIN Product as p
ON s.ProductID = p.ProductID
GROUP BY
	p.ProductID, 
	p.ProductName,
	YEAR (s.SalesDate)
ORDER BY YEAR (s.SalesDate) DESC;


-- 4)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente 
-- NOTA: SI IPOTIZZANO DECRESCENTI SIA DATA CHE FATTURATO

SELECT 
	r.StateName, 
	YEAR(s.SalesDate) as Year, 
	SUM(s.SalesAmount) as TotalSalesYear
FROM Sales as s
LEFT JOIN Region as r
ON s.StateID = r.StateID
GROUP BY 
	r.StateName, 
	YEAR(s.SalesDate)
ORDER BY 
	YEAR(s.SalesDate) DESC,
	SUM(s.SalesAmount) DESC


-- 5)	Rispondere alla seguente domanda: qual � la categoria di articoli maggiormente richiesta dal mercato?

-- IL PRODOTTO CHE HA AVUTO LA MAGGIOR QUANTITA' DI VENDITE E CHE E' STATO IL PIU' RICHIESTO DAL MERCATO E' IL PRODOTTO MICROSOFT GAMES

SELECT 
	p.ProductID,
	p.ProductName,
	SUM(s.SalesAmount) as TotalSalesEver
FROM Sales as s
LEFT JOIN Product as p
ON s.ProductID = p.ProductID
GROUP BY 
	p.ProductID,
	p.ProductName
ORDER BY
	SUM(s.SalesAmount) DESC



-- 6)	Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
-- CI SONO DUE ALTERNATIVE. NELLA PRIMA OCCORRE TROVARE DOVE PRODUCTID RISULTI NULLO OVVERO CHE NON VENGA TROVATO IN SALES. NELLA SECONDA ALTERNATIVA OCCORRE INVECE CAPIRE QUANDO LE VENDITE (SALESAMOUNT) SONO NULLE

SELECT p.ProductID, p.ProductName
FROM Product as p
LEFT JOIN Sales as s
ON p.productID = s.ProductID 
WHERE s.ProductID IS NULL

SELECT p.ProductID, p.ProductName
FROM Product as p
LEFT JOIN Sales as s
ON p.productID = s.ProductID 
WHERE s.SalesAmount IS NULL


-- 7)	Esporre l�elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita pi� recente).
SELECT	
		p.ProductID, 
		p.ProductName, 
		MAX(s.SalesDate) as LastSale
FROM 
		Sales as s
LEFT JOIN Product as p
ON p.ProductID = s.ProductID
GROUP BY p.ProductID, p.ProductName 

--- un altra possibilit�, per esporre ProductName � mettere insieme una JOIN con una GROUP BY

SELECT 
		s1.ProductID, 
		p.ProductName, 
		s1.SalesDate
FROM 
		Sales as s1
LEFT JOIN Product as p
ON s1.ProductID = p.ProductID
WHERE s1.SalesDate IN 
		(SELECT MAX(s2.SalesDate)
		FROM Sales as s2 
		WHERE s1.ProductID = s2.ProductID)
GROUP BY s1.ProductID, p.ProductName, s1.SalesDate


-- 8)	Creare una vista sui prodotti in modo tale da esporre una �versione denormalizzata� delle informazioni utili (codice prodotto, nome prodotto, nome categoria)

CREATE VIEW VW_LastDance_InfoProdotto AS (
SELECT
	ProductID, 
	ProductName, 
	CategoryID,
	CategoryName 
FROM Product
)


-- 9)	Creare una vista per restituire una versione �denormalizzata� delle informazioni geografiche
CREATE VIEW VW_LastDance_InfoGeografiche AS(
SELECT
	StateID, 
	StateName, 
	RegionID,
	RegionName 
FROM Region
)

-- 10)	Esercizio opzionale: ottenute le viste per la costruzione delle dimensioni di analisi prodotto (punto 7)  e area geografica (punto 8), 
-- implementa un modello logico in Power Query e costruisci un report per l�analisi delle vendite

-- CON LA FINALITA' DI OTTENERE UN MODELLO LOGICO IN POWER QUERY SI E' PENSATO DI CREARE UNA VISTA CONSIDERATE LE DIMENSIONI DELLA COLONNA 'SALES' (VENDITA)

CREATE VIEW VW_LastDance_InfoSales AS(
SELECT
	SalesID,
	ProductID,
	StateID,
	Quantity,
	SalesAmount,
	SalesDate
FROM Sales
)





