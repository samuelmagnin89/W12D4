/* Task 2: Descrivi la struttura delle tabelle che reputi utili e sufficienti a modellare lo scenario proposto tramite la sintassi DDL. 
Implementa fisicamente le tabelle utilizzando il DBMS SQL Server (o altro).*/


CREATE TABLE Product
(
ProductID INT, 
ProductName	VARCHAR (25),
CategoryID	VARCHAR (2),
CategoryName VARCHAR (25),
Size	DECIMAL (10,2),
Finishedgood	BIT,
Listprice	DECIMAL (10,2),
Dealerprice	DECIMAL (10,2),
Available BIT, 
CONSTRAINT Pk_ProductID PRIMARY KEY (ProductID),
)
CREATE TABLE Region
(
StateID INT, 
StateName VARCHAR (25), 
RegionID VARCHAR (2), 
RegionName VARCHAR (25),  
CONSTRAINT Pk_StateID PRIMARY KEY (StateID) 
)
CREATE TABLE Sales
(
SalesID	INT,
ProductID INT,
StateID INT,	
Quantity INT,
SalesAmount	DECIMAL (20,2),
SalesDate DATETIME,
CONSTRAINT Pk_SalesID PRIMARY KEY (SalesID), 
CONSTRAINT Fk_ProductID FOREIGN KEY (ProductID) REFERENCES Product (ProductID),
CONSTRAINT Fk_StateID FOREIGN KEY (StateID) REFERENCES Region (StateID),
)


/* Task 3: Popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella; riporta le query utilizzate) */

INSERT INTO Product (ProductID, ProductName, CategoryID, CategoryName, Size, Finishedgood, Listprice, Dealerprice, Available) 
VALUES 
(1, '44Cats', 'A', 'Toys', 4.1, 1, 5, 10, 1), 
(2, 'TrainThomas', 'A', 'Toys',  2.8, 1, 18, 30, 1), 
(3, 'Microsoft Games', 'B', 'Games', 0.6, 0, 155, 200, 1), 
(4, 'Gameboy', 'B', 'Games', 3.1, 1, 60, 100, 0), 
(5, 'Playstation','B', 'Games', 2.4, 1, 175, 300, 0), 
(6, 'Battery', 'C', 'SpareParts', 3.5, 0, 2, 5, 1), 
(7, 'Joystick', 'D', 'Accessories', 1, 1, 10, 30, 1);


INSERT INTO Region (StateID, StateName, RegionID, RegionName)
VALUES
(10, 'Spain', 'EU', 'Europe'),
(11, 'Luxembourg', 'EU', 'Europe'),
(12, 'Ireland', 'EU', 'Europe'), 
(22, 'Mongolia', 'FE', 'Far East'),
(24, 'Japan', 'FE', 'Far East'),
(31, 'Mexico', 'NA', 'North America'),
(32, 'USA', 'NA', 'North America'),
(42, 'SouthAfrica', 'AF', 'Africa');


INSERT INTO Sales (SalesID, ProductID, StateID, Quantity, SalesAmount, SalesDate)
VALUES 
(1, 1, 22, 3, 14, '04/01/24'),
(2, 1, 10, 8, 20, '01/06/23'), 
(3, 2, 31, 7, 126, '25/11/22'), 
(4, 2, 11, 3, 54, '05/04/21'),
(5, 3, 31, 9, 1395, '16/12/20'),
(6, 5, 32, 4, 1280, '04/09/19'),
(7, 4, 32, 6, 120, '02/02/20'),
(8, 6, 42, 3, 60, '04/05/21'); 





